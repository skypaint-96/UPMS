# EDS React Component Library v0.2.94

This library has been updated to support React 19 and React Router v6 while maintaining backward compatibility with previous versions.

## Important Updates

- **React 19 Support**: This version now supports React 19.
- **React Router v6**: Navigation components now work with React Router v6.
- **Backward Compatible**: Still works with React 16.8+, 17.x and 18.x applications.

## Migration Guide

If you're upgrading from a previous version, please read the [Migration Guide](./MIGRATION.md) for detailed instructions.

## Installation

```shell
npm install yarn@latest -g
```

#### Yarn Modern

**This project is not compatible with [Yarn Modern](https://yarnpkg.com/) (version 2 and later).**

### Installation

```shell
yarn
```

#### Mac users with M-series chips will need to prepend `PUPPETEER_SKIP_CHROMIUM_DOWNLOAD=true`.

```shell
PUPPETEER_SKIP_CHROMIUM_DOWNLOAD=true yarn install
```

### Run the app

```shell
yarn dev
```

## Building the Library

```shell
yarn build
```

## Testing

```shell
yarn test:unit
```

For component testing:

```shell
yarn cypress:run:component
```

## Documentation

See the full component documentation for usage examples and API details.
